angular.module('dashboardApp', [
    'ui.bootstrap',
    'chart.js',
    'angular-svg-round-progressbar',
    'ui.router'
]);
